package com.proximichat.client;

import com.proximichat.network.GroupActionPayload;
import com.proximichat.network.GroupListPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import java.util.ArrayList;
import java.util.List;

/**
 * Screen that lets players create, join, and leave voice groups.
 */
public class VoiceGroupScreen extends class_437 {

    private final class_437 parent;
    private static List<String> knownGroups = new ArrayList<>();
    private static String currentGroup = null;

    private class_342 groupNameField;

    public VoiceGroupScreen(class_437 parent) {
        super(class_2561.method_43470("Voice Groups"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx = this.field_22789 / 2;
        int y = this.field_22790 / 4;

        groupNameField = new class_342(this.field_22793,
                cx - 100, y, 200, 20, class_2561.method_43470("Group name"));
        groupNameField.method_1880(32);
        method_37063(groupNameField);

        // Create group
        method_37063(class_4185.method_46430(class_2561.method_43470("Create Group"), btn -> {
            String name = groupNameField.method_1882().trim();
            if (!name.isEmpty()) {
                ClientPlayNetworking.send(new GroupActionPayload(GroupActionPayload.Action.CREATE, name));
                currentGroup = name;
            }
        }).method_46434(cx - 100, y + 25, 95, 20).method_46431());

        // Join group
        method_37063(class_4185.method_46430(class_2561.method_43470("Join Group"), btn -> {
            String name = groupNameField.method_1882().trim();
            if (!name.isEmpty()) {
                ClientPlayNetworking.send(new GroupActionPayload(GroupActionPayload.Action.JOIN, name));
                currentGroup = name;
            }
        }).method_46434(cx + 5, y + 25, 95, 20).method_46431());

        // Leave group
        method_37063(class_4185.method_46430(class_2561.method_43470("Leave Group"), btn -> {
            ClientPlayNetworking.send(new GroupActionPayload(GroupActionPayload.Action.LEAVE, currentGroup != null ? currentGroup : ""));
            currentGroup = null;
        }).method_46434(cx - 100, y + 50, 200, 20).method_46431());

        // Done
        method_37063(class_4185.method_46430(class_5244.field_24334,
                btn -> this.field_22787.method_1507(parent)
        ).method_46434(cx - 75, y + 80, 150, 20).method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25420(context, mouseX, mouseY, delta);
        context.method_27534(this.field_22793, this.field_22785,
                this.field_22789 / 2, this.field_22790 / 4 - 20, 0xFFFFFF);

        // Draw group list
        int y = this.field_22790 / 4 + 110;
        context.method_27535(this.field_22793,
                class_2561.method_43470("Active groups:"), this.field_22789 / 2 - 100, y, 0xAAAAAA);
        for (String g : knownGroups) {
            y += 12;
            String label = g.equals(currentGroup) ? "▶ " + g : "  " + g;
            context.method_27535(this.field_22793,
                    class_2561.method_43470(label), this.field_22789 / 2 - 100, y, 0xFFFFFF);
        }

        super.method_25394(context, mouseX, mouseY, delta);
    }

    // ── S2C: server sends updated group list ──────────────────────────────────

    public static void onGroupList(GroupListPayload payload,
                                   ClientPlayNetworking.Context ctx) {
        knownGroups = new ArrayList<>(payload.groupIds());
    }
}
