package com.proximichat.client;

import com.proximichat.config.ProximiChatConfig;
import com.proximichat.network.VoiceStatePayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Draws a small microphone icon above players who are currently speaking,
 * and a muted icon on the local player when they are muted.
 */
public class VoiceHudRenderer {

    private static final class_2960 SPEAKING_ICON =
            class_2960.method_60655("proximichat", "textures/gui/speaking.png");
    private static final class_2960 MUTED_ICON =
            class_2960.method_60655("proximichat", "textures/gui/muted.png");

    /** UUID → timestamp of last voice packet (for fade-out) */
    private static final Map<UUID, Long> speakingTimestamps = new ConcurrentHashMap<>();
    private static final long ICON_LINGER_MS = 300;

    // ── S2C packet handler ────────────────────────────────────────────────────

    public static void onVoiceState(VoiceStatePayload payload,
                                    ClientPlayNetworking.Context ctx) {
        if (payload.speaking()) {
            speakingTimestamps.put(payload.player(), System.currentTimeMillis());
        } else {
            speakingTimestamps.remove(payload.player());
        }
    }

    // ── HUD render ────────────────────────────────────────────────────────────

    public static void render(class_332 context) {
        if (!ProximiChatConfig.get().showPlayerIcons) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        long now = System.currentTimeMillis();
        int screenW = mc.method_22683().method_4486();
        int screenH = mc.method_22683().method_4502();

        // Mute indicator for local player (bottom left)
        if (VoiceClientHandler.isMuted()) {
            context.method_25290(MUTED_ICON, 4, screenH - 20, 0, 0, 16, 16, 16, 16);
        }

        // Speaking indicator for self (bottom left, green mic)
        if (!VoiceClientHandler.isMuted() && ProximiChatClient.pushToTalkKey.method_1434()) {
            context.method_25290(SPEAKING_ICON, 4, screenH - 20, 0, 0, 16, 16, 16, 16);
        }

        // Clean up stale entries
        speakingTimestamps.entrySet().removeIf(e -> now - e.getValue() > ICON_LINGER_MS);
    }
}
