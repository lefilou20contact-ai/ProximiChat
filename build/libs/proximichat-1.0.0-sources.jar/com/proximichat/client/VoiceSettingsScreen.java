package com.proximichat.client;

import com.proximichat.config.ProximiChatConfig;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;

/**
 * In-game settings screen for ProximiChat.
 * Accessible via the key binding (default: unbound).
 */
public class VoiceSettingsScreen extends class_437 {

    private final class_437 parent;

    public VoiceSettingsScreen(class_437 parent) {
        super(class_2561.method_43471("screen.proximichat.settings"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        ProximiChatConfig cfg = ProximiChatConfig.get();
        int centerX = this.field_22789 / 2;
        int startY = this.field_22790 / 4;

        // Push-to-Talk toggle
        method_37063(class_4185.method_46430(
                class_2561.method_43470("Mode: " + (cfg.pushToTalk ? "Push-to-Talk" : "Voice Activation")),
                btn -> {
                    cfg.pushToTalk = !cfg.pushToTalk;
                    btn.method_25355(class_2561.method_43470("Mode: " + (cfg.pushToTalk ? "Push-to-Talk" : "Voice Activation")));
                    ProximiChatConfig.save();
                }
        ).method_46434(centerX - 100, startY, 200, 20).method_46431());

        // Input gain slider
        method_37063(new class_357(centerX - 100, startY + 30, 200, 20,
                class_2561.method_43470("Mic Volume: " + (int)(cfg.inputGain * 100) + "%"),
                cfg.inputGain) {
            @Override protected void method_25346() {
                method_25355(class_2561.method_43470("Mic Volume: " + (int)(this.field_22753 * 100) + "%"));
            }
            @Override protected void method_25344() {
                cfg.inputGain = (float) this.field_22753;
                ProximiChatConfig.save();
            }
        });

        // Output gain slider
        method_37063(new class_357(centerX - 100, startY + 60, 200, 20,
                class_2561.method_43470("Speaker Volume: " + (int)(cfg.outputGain * 100) + "%"),
                cfg.outputGain) {
            @Override protected void method_25346() {
                method_25355(class_2561.method_43470("Speaker Volume: " + (int)(this.field_22753 * 100) + "%"));
            }
            @Override protected void method_25344() {
                cfg.outputGain = (float) this.field_22753;
                ProximiChatConfig.save();
            }
        });

        // Noise suppression toggle
        method_37063(class_4185.method_46430(
                class_2561.method_43470("Noise Suppression: " + (cfg.enableNoiseSuppression ? "ON" : "OFF")),
                btn -> {
                    cfg.enableNoiseSuppression = !cfg.enableNoiseSuppression;
                    btn.method_25355(class_2561.method_43470("Noise Suppression: " + (cfg.enableNoiseSuppression ? "ON" : "OFF")));
                    ProximiChatConfig.save();
                }
        ).method_46434(centerX - 100, startY + 90, 200, 20).method_46431());

        // Show player icons toggle
        method_37063(class_4185.method_46430(
                class_2561.method_43470("Player Icons: " + (cfg.showPlayerIcons ? "ON" : "OFF")),
                btn -> {
                    cfg.showPlayerIcons = !cfg.showPlayerIcons;
                    btn.method_25355(class_2561.method_43470("Player Icons: " + (cfg.showPlayerIcons ? "ON" : "OFF")));
                    ProximiChatConfig.save();
                }
        ).method_46434(centerX - 100, startY + 120, 200, 20).method_46431());

        // Open group screen
        method_37063(class_4185.method_46430(
                class_2561.method_43470("Voice Groups..."),
                btn -> this.field_22787.method_1507(new VoiceGroupScreen(this))
        ).method_46434(centerX - 100, startY + 155, 200, 20).method_46431());

        // Done
        method_37063(class_4185.method_46430(class_5244.field_24334,
                btn -> this.field_22787.method_1507(parent)
        ).method_46434(centerX - 75, startY + 190, 150, 20).method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25420(context, mouseX, mouseY, delta);
        context.method_27534(this.field_22793, this.field_22785,
                this.field_22789 / 2, this.field_22790 / 4 - 20, 0xFFFFFF);
        super.method_25394(context, mouseX, mouseY, delta);
    }
}
