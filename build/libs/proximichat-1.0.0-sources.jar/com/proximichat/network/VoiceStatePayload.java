package com.proximichat.network;

import com.proximichat.ProximiChat;
import java.util.UUID;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public record VoiceStatePayload(UUID player, boolean speaking) implements class_8710 {

    public static final class_8710.class_9154<VoiceStatePayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655(ProximiChat.MOD_ID, "voice_state"));

    public static final class_9139<class_2540, VoiceStatePayload> CODEC =
            class_9139.method_56438(
                    (p, buf) -> { buf.method_10797(p.player()); buf.method_52964(p.speaking()); },
                    buf -> new VoiceStatePayload(buf.method_10790(), buf.readBoolean())
            );

    @Override public class_8710.class_9154<? extends class_8710> method_56479() { return ID; }
}
