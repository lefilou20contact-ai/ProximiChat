package com.proximichat.network;

import com.proximichat.ProximiChat;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public record GroupListPayload(List<String> groupIds) implements class_8710 {

    public static final class_8710.class_9154<GroupListPayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655(ProximiChat.MOD_ID, "group_list"));

    public static final class_9139<class_2540, GroupListPayload> CODEC =
            class_9139.method_56438(
                    (p, buf) -> {
                        buf.method_10804(p.groupIds().size());
                        p.groupIds().forEach(g -> buf.method_10788(g, 64));
                    },
                    buf -> {
                        int size = buf.method_10816();
                        List<String> list = new ArrayList<>(size);
                        for (int i = 0; i < size; i++) list.add(buf.method_10800(64));
                        return new GroupListPayload(list);
                    }
            );

    @Override public class_8710.class_9154<? extends class_8710> method_56479() { return ID; }
}
