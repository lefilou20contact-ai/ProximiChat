package com.proximichat.network;

import com.proximichat.ProximiChat;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public record ClientConnectedPayload(int clientVersion) implements class_8710 {

    public static final class_8710.class_9154<ClientConnectedPayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655(ProximiChat.MOD_ID, "client_connected"));

    public static final class_9139<class_2540, ClientConnectedPayload> CODEC =
            class_9139.method_56438(
                    (p, buf) -> buf.method_10804(p.clientVersion()),
                    buf -> new ClientConnectedPayload(buf.method_10816())
            );

    @Override public class_8710.class_9154<? extends class_8710> method_56479() { return ID; }
}
