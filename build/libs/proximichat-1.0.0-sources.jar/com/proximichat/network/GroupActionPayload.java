package com.proximichat.network;

import com.proximichat.ProximiChat;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public record GroupActionPayload(Action action, String groupId) implements class_8710 {

    public enum Action { CREATE, JOIN, LEAVE }

    public static final class_8710.class_9154<GroupActionPayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655(ProximiChat.MOD_ID, "group_action"));

    public static final class_9139<class_2540, GroupActionPayload> CODEC =
            class_9139.method_56438(
                    (p, buf) -> {
                        buf.method_10817(p.action());
                        buf.method_10788(p.groupId(), 64);
                    },
                    buf -> new GroupActionPayload(
                            buf.method_10818(Action.class),
                            buf.method_10800(64)
                    )
            );

    @Override public class_8710.class_9154<? extends class_8710> method_56479() { return ID; }
}
