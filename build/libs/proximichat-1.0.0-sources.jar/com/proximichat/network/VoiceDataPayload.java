package com.proximichat.network;

import com.proximichat.ProximiChat;
import java.util.UUID;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Carries a chunk of Opus-encoded audio from one player to the server,
 * which then forwards it to nearby players.
 */
public record VoiceDataPayload(
        UUID senderUuid,
        byte[] opusData,
        boolean whisper
) implements class_8710 {

    public static final class_8710.class_9154<VoiceDataPayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655(ProximiChat.MOD_ID, "voice_data"));

    public static final class_9139<class_2540, VoiceDataPayload> CODEC =
            class_9139.method_56438(VoiceDataPayload::write, VoiceDataPayload::read);

    private static VoiceDataPayload read(class_2540 buf) {
        UUID uuid     = buf.method_10790();
        byte[] data   = buf.method_10803(4096); // max ~4 KB per frame
        boolean wh    = buf.readBoolean();
        return new VoiceDataPayload(uuid, data, wh);
    }

    private void write(class_2540 buf) {
        buf.method_10797(senderUuid);
        buf.method_10813(opusData);
        buf.method_52964(whisper);
    }

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
